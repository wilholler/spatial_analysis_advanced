# Plugin de Análise de Autocorrelação Espacial para QGIS

## Descrição

Este plugin implementa métodos estatisticamente robustos para análise de autocorrelação espacial, incluindo:

- **I de Moran Global**: Medida de autocorrelação espacial global com testes de permutação
- **LISA (Local Indicators of Spatial Association)**: Identificação de hotspots, coldspots e outliers espaciais
- **Tratamento especializado para dados de contagem**: Usando transformações apropriadas para distribuições de Poisson
- **Visualização automática**: Mapas temáticos com simbolização baseada nos padrões detectados
- **Interface educativa**: Explicações detalhadas sobre cada método e parâmetro

## Pré-requisitos

### Dependências Python Necessárias

O plugin requer as seguintes bibliotecas Python que podem não estar incluídas na instalação padrão do QGIS:

- **NumPy** (geralmente já incluído)
- **SciPy** (frequentemente ausente)

### Instalação das Dependências

#### Windows (Instalação OSGeo4W - Recomendado)

1. **Abra o OSGeo4W Shell como Administrador**:
   - Encontre "OSGeo4W Shell" no menu Iniciar
   - Clique com o botão direito e selecione "Executar como administrador"

2. **Execute os comandos**:
   ```bash
   python -m pip install scipy
   ```

3. **Reinicie o QGIS**

#### Windows (Instalação Standalone do QGIS)

1. **Abra o Prompt de Comando como Administrador**
2. **Navegue até o diretório Python do QGIS** (exemplo):
   ```bash
   cd "C:\Program Files\QGIS 3.x\apps\Python39"
   ```
3. **Execute**:
   ```bash
   python -m pip install scipy
   ```

#### Linux (Ubuntu/Debian)

```bash
sudo apt update
sudo apt install python3-scipy
```

#### macOS

```bash
pip3 install scipy
```

## Instalação do Plugin

### Método 1: Instalação Manual

1. **Baixe os arquivos do plugin**
2. **Localize o diretório de plugins do QGIS**:
   - Windows: `C:\Users\[SeuUsuário]\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
   - Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

3. **Crie uma pasta chamada** `spatial_analysis_advanced`

4. **Copie todos os arquivos para esta pasta**:
   ```
   spatial_analysis_advanced/
   ├── __init__.py
   ├── metadata.txt
   ├── spatial_analysis.py
   ├── icon.png (opcional)
   └── README.md
   ```

5. **Reinicie o QGIS**

6. **Ative o plugin**:
   - Vá para "Complementos > Gerenciar e Instalar Complementos"
   - Na aba "Instalados", encontre "Análise de Autocorrelação Espacial Avançada"
   - Marque a caixa para ativar

### Método 2: Descobrir o Diretório Automaticamente

No QGIS, você pode descobrir o diretório correto:
1. Vá para "Configurações > Opções do Usuário"
2. Selecione a aba "Sistema"
3. Procure por "Caminhos de plugins do usuário"

## Resolução de Problemas Comuns

### Erro: "AttributeError: type object 'QgsMapLayerComboBox' has no attribute 'VectorLayer'"

**Causa**: Versão do código incompatível com sua versão do QGIS.
**Solução**: Use a versão corrigida do código fornecida.

### Erro: "ModuleNotFoundError: No module named 'scipy'"

**Causa**: Biblioteca SciPy não instalada.
**Solução**: Siga as instruções de instalação de dependências acima.

### Plugin não aparece na lista

**Possíveis causas e soluções**:
1. **Arquivos no local errado**: Verifique se estão no diretório correto
2. **Erro no metadata.txt**: Verifique se não há caracteres especiais problemáticos
3. **Erro no __init__.py**: Verifique se a sintaxe está correta
4. **Marque "Mostrar plugins experimentais"** na janela de plugins

### Plugin carrega mas não funciona

1. **Abra o Console Python** (Complementos > Console Python)
2. **Procure por mensagens de erro** quando tentar usar o plugin
3. **Verifique se todas as dependências estão instaladas**

## Como Usar

### Dados Requeridos

- **Camada vetorial**: Polígonos, pontos ou linhas
- **Campo numérico**: Contendo os valores para análise
- **Mínimo 3 feições**: Necessário para análise estatística válida

### Fluxo de Trabalho Típico

1. **Carregue sua camada vetorial** no QGIS
2. **Acesse o plugin**: Vetor > Análise Espacial > Análise Espacial Avançada
3. **Configure os parâmetros**:
   - Selecione a camada e campo
   - Escolha o tipo de dados (contagem, contínuo, taxa)
   - Defina o critério de vizinhança
   - Configure as análises desejadas
4. **Execute a análise**
5. **Examine os resultados**:
   - Dialog com resultados estatísticos
   - Nova camada com resultados LISA (se selecionado)
   - Mapa temático automático

### Tipos de Dados

- **Contagem (Poisson)**: Para dados como número de crimes, casos de doenças, estabelecimentos
- **Contínuo (Gaussiano)**: Para dados como renda, temperatura, densidade populacional
- **Taxa/Proporção**: Para percentuais ou razões

### Critérios de Vizinhança

- **Queen**: Considera vizinhos que compartilham qualquer fronteira ou vértice
- **Rook**: Considera apenas vizinhos que compartilham fronteiras
- **K-vizinhos**: Define um número fixo de vizinhos mais próximos
- **Distância fixa**: Define vizinhos dentro de um raio específico

## Interpretação dos Resultados

### I de Moran Global

- **I > E[I] e p < 0.05**: Autocorrelação espacial positiva (agrupamento)
- **I < E[I] e p < 0.05**: Autocorrelação espacial negativa (dispersão)
- **p ≥ 0.05**: Distribuição espacial aleatória

### LISA Local

- **High-High (Vermelho)**: Hotspots - valores altos cercados por valores altos
- **Low-Low (Azul)**: Coldspots - valores baixos cercados por valores baixos
- **High-Low (Laranja)**: Outliers - valores altos em áreas de valores baixos
- **Low-High (Roxo)**: Outliers - valores baixos em áreas de valores altos
- **Cinza**: Sem padrão espacial significativo

## Suporte e Contribuições

Para reportar bugs, solicitar funcionalidades ou contribuir com código:
- **Issues**: [GitHub Issues](https://github.com/seuusuario/spatial-analysis-advanced/issues)
- **Código**: [GitHub Repository](https://github.com/seuusuario/spatial-analysis-advanced)

## Licença

Este plugin é distribuído sob [licença apropriada - especifique aqui]

## Citação

Se você usar este plugin em pesquisa acadêmica, por favor cite:

```
[Seu Nome]. (2025). Plugin de Análise de Autocorrelação Espacial para QGIS. 
Versão 1.0.0. [URL do repositório]
```